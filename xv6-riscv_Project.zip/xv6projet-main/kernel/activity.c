#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "activity.h"

extern struct proc proc[NPROC];          
uint global_interrupt_count = 0;          
extern uint console_activity_counter;    

static uint last_int_count = 0;          
static uint last_console_count = 0;       
static uint high_cpu_counter = 0;         
static uint timestamp_seconds = 0;        
static uint last_timestamp_tick = 0;      

int calculate_cpu_percent(void) {
    struct proc *p;
    int running_count = 0;
    int total_processes = 0;
    
    for(p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if(p->state != UNUSED) {
            total_processes++;
            
            if(p->state == RUNNING) {
                running_count++;
            } else if(p->state == RUNNABLE && p->ticks_cpu > 10) {
                running_count++;
            }
        }
        release(&p->lock);
    }
    
    if(total_processes == 0) return 0;
    
    int base_percent = running_count * 20;
    
    uint total_ticks = 0;
    for(p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if(p->state != UNUSED) {
            total_ticks += p->ticks_cpu;
        }
        release(&p->lock);
    }
    
    if(total_ticks > 1000) {
        base_percent += 20;
    } else if(total_ticks > 5000) {
        base_percent += 40;
    }
    
    if(base_percent > 100) base_percent = 100;
    if(base_percent < 0) base_percent = 0;
    
    return base_percent;
}

int calculate_mem_percent(void) {
    
    uint64 total_memory = PHYSTOP - KERNBASE;          
    uint64 total_pages = total_memory / PGSIZE;         
    
    if(total_pages == 0) {
        return 25;  
    }
    

    uint64 free_pages = count_free_pages();
    
    uint64 used_pages = total_pages - free_pages;
    
    int percent = (int)((used_pages * 100) / total_pages);
    
    if(percent > 100) percent = 100;
    if(percent < 10) percent = 10;  
    
    return percent;
}

int detect_user_activity(void) {
    static uint last_activity_time = 0;
    uint current_time = global_interrupt_count; 
    
    if(console_activity_counter != last_console_count) {
        last_console_count = console_activity_counter;
        last_activity_time = current_time;
        return 1; 
    }
    
    if((current_time - last_activity_time) < 20) {
        return 1;  
    }
    
    return 0;  
}

int get_interrupt_delta(void) {
    int delta = (int)(global_interrupt_count - last_int_count);
    last_int_count = global_interrupt_count;
    
    if(delta < 0) delta = 0;
    if(delta > 1000) delta = 1000;  
    
    return delta;
}

int determine_state(int cpu_percent, int mem_percent, int user_activity) {
    if(cpu_percent > 60) {
        high_cpu_counter++;
        if(high_cpu_counter > 2) {
            return STATE_OCCUPE; 
        }
    } else {
        high_cpu_counter = 0;  
    }
    
    if(user_activity == 1) {
        return STATE_OCCUPE;
    }
    
    if(mem_percent > 75) {
        return STATE_OCCUPE;
    }
    
    if(cpu_percent > 40 && global_interrupt_count - last_int_count > 50) {
        return STATE_OCCUPE;
    }
    
    return STATE_LIBRE;
}

void get_timestamp(char *buf, int size) {
    uint current_ticks = global_interrupt_count;
    if(current_ticks - last_timestamp_tick >= 10) {
        timestamp_seconds += (current_ticks - last_timestamp_tick) / 10;
        last_timestamp_tick = current_ticks;
    }
    
    int seconds = timestamp_seconds;
    int len = 0;

    if(len < size-1) buf[len++] = '[';
    
    if(seconds == 0) {
        if(len < size-1) buf[len++] = '0';
    } else {
        char digits[10];
        int num_digits = 0;
        int temp = seconds;
        
        while(temp > 0 && num_digits < 10) {
            digits[num_digits++] = '0' + (temp % 10);
            temp /= 10;
        }
        for(int i = num_digits-1; i >= 0; i--) {
            if(len < size-1) {
                buf[len++] = digits[i];
            }
        }
    }
    if(len < size-1) buf[len++] = 's';
    if(len < size-1) buf[len++] = ']';
    buf[len] = '\0';
}

int sys_getactivity(void) {
    uint64 addr;
    struct activity act;
    struct proc *p = myproc();
    if(p == 0) {
        return -1;
    }
    argaddr(0, &addr);
    act.cpu_percent = calculate_cpu_percent();
    act.mem_percent = calculate_mem_percent();
    act.user_activity = detect_user_activity();
    act.interrupts = get_interrupt_delta();
    act.state = determine_state(act.cpu_percent, act.mem_percent, act.user_activity);
    get_timestamp(act.timestamp, sizeof(act.timestamp));
    if(copyout(p->pagetable, addr, (char*)&act, sizeof(act)) < 0) {
        return -1;  
    }
    
    return 0;  
}