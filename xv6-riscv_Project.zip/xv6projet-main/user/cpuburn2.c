#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Fonction très intensive
void burn_cpu() {
    volatile long x = 123456789;
    for(int i = 0; i < 1000000; i++) {
        x = (x * 1103515245 + 12345) & 0x7fffffff;
        if((i % 100000) == 0) {
            // Petit affichage occasionnel
            printf(".");
        }
    }
}

int main() {
    printf("=== CPU BURN INTENSIVE ===\n");
    printf("Creating 4 processes for 15 seconds...\n\n");
    
    // Créer plusieurs processus
    for(int p = 0; p < 4; p++) {
        if(fork() == 0) {
            // Enfant : brûler du CPU
            printf("Process %d started\n", getpid());
            while(1) {
                burn_cpu();
            }
        }
    }
    
    // Parent : attendre
    printf("Parent waiting 150 ticks (15 seconds)...\n");
    
    // Attente (si pause() disponible)
    // pause(150);
    
    // Sinon boucle d'attente
    for(int t = 0; t < 15; t++) {
        printf("%d... ", 15-t);
        for(int i = 0; i < 10000000; i++) {
            asm volatile("nop");
        }
    }
    printf("\n");
    
    // Tuer tout
    printf("Killing all processes...\n");
    while(wait(0) >= 0) {
        // Continuer à attendre
    }
    
    printf("=== TEST COMPLETE ===\n");
    return 0;
}
