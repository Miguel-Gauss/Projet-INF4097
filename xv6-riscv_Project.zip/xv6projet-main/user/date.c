// #include "kernel/types.h"
// #include "kernel/stat.h"
// #include "user/user.h"
// #include "kernel/date.h"

// int
// main(int argc, char *argv[])
// {
//   struct rtcdate r;

//   if (date(&r)) {
//     printf(2, "date failed\n");
//     exit(1);
//   }

//   // Format: Année-Mois-Jour Heure:Minute:Seconde
//   printf(1, "%d-%d-%d %d:%d:%d\n", 
//          r.year, r.month, r.day, 
//          r.hour, r.minute, r.second);
//   exit(0);
// }
