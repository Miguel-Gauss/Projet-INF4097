#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    struct activity act;
    
    printf("=== Test de getactivity() ===\n");
    
    int result = getactivity(&act);
    
    if(result < 0) {
        printf("ERREUR: getactivity a échoué (code: %d)\n", result);
        exit(1);
    }
    
    printf("SUCCÈS! getactivity() fonctionne.\n\n");
    printf("Détails:\n");
    printf("  Charge CPU: %d%%\n", act.cpu_percent);
    printf("  Mémoire utilisée: %d%%\n", act.mem_percent);
    printf("  Activité utilisateur: %d\n", act.user_activity);
    printf("  Interruptions: %d\n", act.interrupts);
    printf("  État: %s\n", act.state == 0 ? "LIBRE" : "OCCUPÉ");
    printf("  Timestamp: %s\n", act.timestamp);
    
    printf("\n=== Test terminé avec succès ===\n");
    return 0;
}
