#include "user/user.h"

#define PAGE 4096

int main() {
    printf("=== Lazy Allocation Test ===\n");
    
    char *ptr = sbrk(5 * PAGE);
    printf("sbrk(5 pages) returned: %p\n", ptr);
    printf("Accessing page 0...\n");
    ptr[0] = 'X';
    printf("  Wrote 'X' to address %p\n", &ptr[0]);
    printf("Accessing page 2...\n");
    ptr[2 * PAGE] = 'Y';
    printf("  Wrote 'Y' to address %p\n", &ptr[2 * PAGE]);
    printf("Pages 1, 3, 4 are still not allocated\n");
    printf("Verification:\n");
    printf("  Page 0 contains: %c\n", ptr[0]);
    printf("  Page 2 contains: %c\n", ptr[2 * PAGE]);
    printf("\nTest completed successfully!\n");
    return 0;
}
