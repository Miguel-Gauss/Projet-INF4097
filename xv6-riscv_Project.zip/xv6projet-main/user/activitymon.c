#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    struct activity act;
    
    printf("Appuyez sur Ctrl+C pour arrêter\n\n");
    
    int count = 0;
    while(1) {
        if(getactivity(&act) < 0) {
            printf("Erreur lors de l'appel à getactivity\n");
            break;
        }
        
        printf("[%s] État: %s CPU=%d%% MEM=%d%% user=%d intr=%d (mesure #%d)\n",
               act.timestamp,
               act.state == 0 ? "LIBRE" : "OCCUPÉ",
               act.cpu_percent,
               act.mem_percent,
               act.user_activity,
               act.interrupts,
               ++count);
        
        pause(50);  // 5 secondes (50 ticks)
    }
    
    return 0;
}