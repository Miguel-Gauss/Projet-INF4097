#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void worker(int id, int tickets) {
    settickets(tickets);
    printf("Process %d: %d tickets, PID=%d\n", id, tickets, getpid());
    
    volatile long x = 0;
    for(int i = 0; i < 100000000; i++) {
        x = x * i + 12345;
    }
    
    printf("Process %d finished\n", id);
    exit(0);
}

int main() {
    printf("=== Lottery Scheduler Test ===\n");
    printf("Creating 3 processes with different tickets...\n");
    
   
    if(fork() == 0) {
        worker(1, 10);
    }
    
    
    if(fork() == 0) {
        worker(2, 30);
    }
    
    
    if(fork() == 0) {
        worker(3, 60);
    }
    
   
    for(int i = 0; i < 3; i++) {
        wait(0);
    }
    
    printf("\nTest completed.\n");
    return 0;
}
