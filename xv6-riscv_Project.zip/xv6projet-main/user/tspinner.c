#include "user/user.h"

int main(int argc, char *argv[]) {
    int t = 10;
    
    if(argc > 1) {
        t = atoi(argv[1]);
    }
    
    settickets(t);
    printf("Spin: %d tickets, PID=%d\n", t, getpid());
    
    int c = 0;
    while(1) {
        c++;
        if(c % 20000000 == 0) {
            printf("PID=%d (t=%d): running\n", getpid(), t);
        }
    }
    
    return 0;
}
