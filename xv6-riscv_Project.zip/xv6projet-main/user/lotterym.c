#include "user/user.h"

#define WORK 40000000

void worker(int id, int t) {
    settickets(t);
    printf("W%d: %d tickets, PID=%d\n", id, t, getpid());
    
    volatile long x = 0;
    int c = 0;
    
    for(int i = 0; i < WORK; i++) {
        x = x * i + 12345;
        c++;
        
        if(c % 10000000 == 0) {
            printf("  W%d: %d/%d\n", id, c, WORK);
        }
    }
    
    printf("W%d DONE\n", id);
    exit(0);
}

int main() {
    printf("Lottery Measure: tickets 10,30,60\n");
    
    for(int i = 0; i < 3; i++) {
        int t;
        if(i == 0) t = 10;
        else if(i == 1) t = 30;
        else t = 60;
        
        if(fork() == 0) {
            worker(i+1, t);
        }
    }
    
    for(int i = 0; i < 3; i++) {
        wait(0);
    }
    
    printf("All done\n");
    return 0;
}
