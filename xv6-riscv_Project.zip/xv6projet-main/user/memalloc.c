#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("=== Memory Test Program ===\n");
    
    int total_kb = 0;
    const int page_size = 4096;
    
    printf("Allocating memory in chunks...\n\n");
    
    for(int chunk = 0; chunk < 8; chunk++) {
        char *block = sbrk(page_size * 4); 
        
        if(block == (char*)-1) {
            printf("Allocation stopped at %d KB\n", total_kb);
            break;
        }
        
        total_kb += 16;
        
        for(int i = 0; i < page_size * 4; i += 512) {
            block[i] = (chunk + i) % 256;
        }
        
        printf("Allocated: %d KB total\n", total_kb);
        
        for(int w = 0; w < 100000; w++);
    }
    
    printf("\nTotal allocated: %d KB\n", total_kb);
    printf("Memory should now show higher usage in activitymon\n\n");
    
    printf("Maintaining allocation for 12 seconds...\n");
    for(int sec = 12; sec > 0; sec--) {
        printf("Time left: %2d seconds\r", sec);
        volatile long delay;
        for(delay = 0; delay < 800000; delay++);
    }
    
    printf("\n\nTest complete. Exiting.\n");
    return 0;
}
