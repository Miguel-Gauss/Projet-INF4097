#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("=== CPU Stress Test ===\n");
    
    for(int i = 0; i < 3; i++) {
        if(fork() == 0) {
            long x = 0;
            while(1) {
                for(int j = 0; j < 100000; j++) {
                    x = x * j + 12345;
                }
            }
        }
    }
    
    printf("Running for 30 seconds...\n");
    for(int sec = 30; sec > 0; sec--) {
        printf("%d... ", sec);
        for(int w = 0; w < 10000000; w++);
    }
    printf("\nDone!\n");
    
    return 0;
}