while true; do echo 'working'; done
