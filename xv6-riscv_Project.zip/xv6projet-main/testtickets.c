#include "user/user.h"

int main() {
    printf("Testing settickets()...\n");
    
    if(settickets(25) == 0) {
        printf("✓ settickets(25) succeeded\n");
    } else {
        printf("✗ settickets(25) failed\n");
    }
    
    printf("Testing ticket values:\n");
    
    settickets(-10);
    printf("  settickets(-10) - should become 1\n");
    
    settickets(0);
    printf("  settickets(0) - should become 1\n");
    
    settickets(1000);
    printf("  settickets(1000) - OK\n");
    
    printf("\nTest completed.\n");
    return 0;
}
