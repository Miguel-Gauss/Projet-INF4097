#ifndef _ACTIVITY_H_
#define _ACTIVITY_H_

struct activity {
    int cpu_percent;     // charge cpu estimée (0..100)
    int mem_percent;     // mémoire utilisée en %
    int user_activity;   // 0/1 (activité clavier simulée)
    int interrupts;      // nb d'interruptions sur intervalle
    int state;           // 0 = LIBRE, 1 = OCCUPE
    char timestamp[32];  // horodatage ISO
};


#define STATE_LIBRE  0
#define STATE_OCCUPE 1

#endif