#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "activity.h"

static uint64 last_measure_ticks = 0;
static uint64 last_total_cpu_ticks = 0;
static uint64 last_interrupt_count = 0;
static uint64 last_console_activity = 0;

uint64 global_interrupt_count = 0;

uint64 console_activity_counter = 0;

void get_timestamp(char *buf, int size) {
  uint64 ticks = sys_uptime();
  snprintf(buf, size, "T+%d", (int)ticks);
}

int calculate_cpu_percent(void) {
    struct proc *p;
    uint64 total_ticks = 0;
    uint64 current_ticks = sys_uptime();

 for(p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if(p->state != UNUSED) {
            total_ticks += p->ticks_cpu;
        }
        release(&p->lock);
    }

    uint64 delta_ticks = current_ticks - last_measure_ticks;
    uint64 delta_cpu = total_ticks - last_total_cpu_ticks;
    

    last_measure_ticks = current_ticks;
    last_total_cpu_ticks = total_ticks;

    if(delta_ticks == 0) {
        return 0;
    }
    int percent = (int)((delta_cpu * 100) / delta_ticks);
    if(percent > 100) percent = 100;
    
    return percent;
}

int calculate_mem_percent(void) {
    uint64 total_pages = PHYSTOP / PGSIZE;
    uint64 free_pages = count_free_pages(); // À implémenter dans kalloc.c
    uint64 used_pages = total_pages - free_pages;
    
    int percent = (int)((used_pages * 100) / total_pages);
    return percent;
}
// Détecter activité utilisateur récente
int detect_user_activity(void) {
    uint64 current_ticks = sys_uptime();
    
    // Si activité console dans les derniers 10 ticks (~1 seconde)
    if((current_ticks - last_console_activity) < 100) {
        return 1;
    }
    
    // Vérifier si il y a eu des changements dans le compteur console
    if(console_activity_counter != last_console_activity) {
        last_console_activity = console_activity_counter;
        return 1;
    }
    
    return 0;
}

// Obtenir le nombre d'interruptions depuis la dernière mesure
int get_interrupt_delta(void) {
    int delta = (int)(global_interrupt_count - last_interrupt_count);
    last_interrupt_count = global_interrupt_count;
    return delta;
}

// Déterminer l'état (LIBRE ou OCCUPÉ)
int determine_state(int cpu_percent, int mem_percent, int user_activity) {
    // Règles de décision
    if(cpu_percent > 50) {
        return STATE_OCCUPE;
    }
    
    if(user_activity == 1) {
        return STATE_OCCUPE;
    }
    
    if(mem_percent > 70) {
        return STATE_OCCUPE;
    }
    
    return STATE_LIBRE;
}

// Implémentation du syscall getactivity
int sys_getactivity(void) {
    uint64 addr;
    struct activity act;
    
    // Récupérer l'adresse du buffer utilisateur
    if(argaddr(0, &addr) < 0)
        return -1;
    
    // Collecter les métriques
    act.cpu_percent = calculate_cpu_percent();
    act.mem_percent = calculate_mem_percent();
    act.user_activity = detect_user_activity();
    act.interrupts = get_interrupt_delta();
    act.state = determine_state(act.cpu_percent, act.mem_percent, act.user_activity);
    
    // Obtenir le timestamp
    get_timestamp(act.timestamp, sizeof(act.timestamp));
    
    // Copier vers l'espace utilisateur
    if(copyout(myproc()->pagetable, addr, (char*)&act, sizeof(act)) < 0)
        return -1;
    
    return 0;
}

