#ifndef _ACTIVITY_H_
#define _ACTIVITY_H_

struct activity {
    int cpu_percent;
    int mem_percent;
    int user_activity;
    int interrupts;
    int state;
    char timestamp[32];
};

#define STATE_LIBRE  0
#define STATE_OCCUPE 1

#endif // _ACTIVITY_H_
