#include "user/user.h"

int main() {
    printf("Advanced Lazy Test\n");
    
    char *p = sbrk(100 * 4096);
    printf("Allocated 100 pages virtually\n");
    
    for(int i = 0; i < 100; i += 2) {
        p[i * 4096] = i % 26 + 'A';
    }
    
    printf("Accessed only even pages (0,2,4,...)\n");
    printf("Odd pages (1,3,5,...) are still lazy\n");
    
    return 0;
}
