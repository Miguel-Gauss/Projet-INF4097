#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("CPU burn running...\n");
    long x = 0;
    while(1) {
        for(int i = 0; i < 100000; i++) {
            x = x * i + 12345;
        }
    }
    return 0;
}
